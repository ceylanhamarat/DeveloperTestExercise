﻿using FileData;
using FileData.Helper;
using NUnit.Framework;
using System.Linq;
using ThirdPartyTools; 
namespace FileDataTest
{
    [TestFixture]
    public class GetAllInstanceInterfaceTest
    {
        [TestCase]
        public void When_TheGetTheParsesList_Expect_NineElementReturns()
        {
            // -v c:/test.txt
            var argumentParser = new FileInfoArgumentParser();

            Assert.AreEqual(argumentParser.GetParsers().ToList().Count, 9);
        }


        [TestCase]
        public void When_TheGetThePrintersList_Expect_TwoElementReturns()
        {
            // -v c:/test.txt
            var fileDetails = new FileDetails();

            var argumentParser = new FileInfoPrinter(fileDetails);

            Assert.AreEqual(argumentParser.GetPrinters().ToList().Count, 2);
        }

    }
}
