﻿using FileData.Abstractions;
using FileData.Parsers;
using NUnit.Framework;
using FileData.Model;
using FileData.Enum;
namespace FileDataTest
{
    [TestFixture]
   public class ParsersTest
    {
        [TestCase]
        public void When_TheArgumentStartWithMinusV_Expect_ArgumentDetailIsEqualVersion()
        {
            // -v c:/test.txt
            IParseArgument parser = new Version1Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "-v", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail, FileDetail.Version);
            Assert.AreEqual(arguments.Path, null);
        }

        [TestCase]
        public void When_TheArgumentStartWithTwoMinusV_Expect_ArgumentDetailIsEqualVersion()
        {
            // -v c:/test.txt
            IParseArgument parser = new Version2Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "--v", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail,  FileDetail.Version);
            Assert.AreEqual(arguments.Path, null);
        }


        [TestCase]
        public void When_TheArgumentStartWithSlashV_Expect_ArgumentDetailIsEqualVersion()
        {
            // -v c:/test.txt
            IParseArgument parser = new Version3Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "/v", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail, FileDetail.Version);
            Assert.AreEqual(arguments.Path, null);
        }


        [TestCase]
        public void When_TheArgumentStartWithTwoMinusVersion_Expect_ArgumentDetailIsEqualVersion()
        {
            // -v c:/test.txt
            IParseArgument parser = new Version4Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "--version", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail,  FileDetail.Version);
            Assert.AreEqual(arguments.Path, null);
        }


        [TestCase]
        public void When_TheArgumentStartWithMinusS_Expect_ArgumentDetailIsEqualSize()
        {
            // -v c:/test.txt
            IParseArgument parser = new Size1Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "-s", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail, FileDetail.Size);
            Assert.AreEqual(arguments.Path, null);
        }

        [TestCase]
        public void When_TheArgumentStartWithTwoMinusS_Expect_ArgumentDetailIsEqualSize()
        {
            // -v c:/test.txt
            IParseArgument parser = new Size2Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "--s", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail, FileDetail.Size);
            Assert.AreEqual(arguments.Path, null);
        }


        [TestCase]
        public void When_TheArgumentStartWithSlashS_Expect_ArgumentDetailIsEqualSize()
        {
            // -v c:/test.txt
            IParseArgument parser = new Size3Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "/s", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail, FileDetail.Size);
            Assert.AreEqual(arguments.Path, null);
        }


        [TestCase]
        public void When_TheArgumentStartWithTwoMinusSize_Expect_ArgumentDetailIsEqualSize()
        {
            // -v c:/test.txt
            IParseArgument parser = new Size4Parser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "--size", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail,FileDetail.Size);
            Assert.AreEqual(arguments.Path, null);
        }


        [TestCase]
        public void When_ParseInputStringArray_Expect_FileInfoArguments()
        {
            // -v c:/test.txt
            IParseArgument parser = new FilePathParser();

            var arguments = new FileInfoArguments();

            var input = new string[] { "--s", "c:/test.txt" };

            parser.ParseArgument(arguments, input);

            Assert.AreEqual(arguments.Detail, FileDetail.Size);
            Assert.AreEqual(arguments.Path, "c:/test.txt");
        }
    }
}
