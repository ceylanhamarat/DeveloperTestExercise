﻿using FileData.Helper;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            var fileInfoParser = new FileInfoArgumentParser();
            var fileInfoArgs = fileInfoParser.Parse(args);
            var fileDetails = new FileDetails();
            var fileInfoPrinter = new FileInfoPrinter(fileDetails);
            fileInfoPrinter.Print(fileInfoArgs);
        }
    }
}
