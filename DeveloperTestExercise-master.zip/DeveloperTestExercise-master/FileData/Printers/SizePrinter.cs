﻿using FileData.Abstractions;
using FileData.Enum;
using FileData.Model;
using System;
using ThirdPartyTools;

namespace FileData.Printers
{
    public class SizePrinter : IGetPrinterOutput
    {
        public FileDetails FileDetails { get; set; }
        public SizePrinter()
        {

        }
        public void GetOutput(FileInfoArguments arguments)
        {
            if (arguments.Detail == FileDetail.Size)
            {
                var size = FileDetails.Size(arguments.Path);
                Console.WriteLine($"Size: {size}");
            }
        }
    }
}
