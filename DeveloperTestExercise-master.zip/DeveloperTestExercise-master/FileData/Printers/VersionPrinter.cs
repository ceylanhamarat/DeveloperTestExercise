﻿using FileData.Abstractions;
using FileData.Enum;
using FileData.Model;
using System;
using ThirdPartyTools;

namespace FileData.Printers
{
    public class VersionPrinter : IGetPrinterOutput
    {
        public FileDetails FileDetails { get; set; }
        public VersionPrinter()
        {

        }
        public void GetOutput(FileInfoArguments arguments)
        {
            if (arguments.Detail == FileDetail.Version)
            {
                var version = FileDetails.Version(arguments.Path);
                Console.WriteLine($"Version: {version}");
            }
        }        
    }
}
