﻿using FileData.Abstractions;
using FileData.Enum;
using FileData.Model;

namespace FileData.Parsers
{
    public class Version3Parser : IParseArgument
    {
        public void ParseArgument(FileInfoArguments arguments, string[] input)
        {
            if(input.Length > 0)
            {
                if(input[0] == "/v")
                {
                    arguments.Detail = FileDetail.Version;
                }
            }
        }

       
    }
}
