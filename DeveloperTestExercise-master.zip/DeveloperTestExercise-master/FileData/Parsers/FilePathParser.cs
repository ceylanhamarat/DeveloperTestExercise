﻿using FileData.Abstractions;
using FileData.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileData.Parsers
{
    public class FilePathParser : IParseArgument
    {
        public void ParseArgument(FileInfoArguments arguments, string[] input)
        {
            if(input.Length > 1)
            {
                arguments.Path = input[1];
            }
        }
    }
}
