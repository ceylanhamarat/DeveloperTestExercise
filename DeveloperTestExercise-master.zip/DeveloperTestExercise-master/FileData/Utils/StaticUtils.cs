﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileData.Utils
{/// <summary>
 /// Sourced from stackoverflow: https://stackoverflow.com/questions/5120647/instantiate-all-classes-implementing-a-specific-interface
 /// </summary>
    public static class StaticUtils
    {
        public static IEnumerable<T> GetInstancesOfType<T>()
        {
            var interfaceType = typeof(T);

            var all = interfaceType.Assembly
              .GetTypes()
              .Where(x => interfaceType.IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract)
              .Select(x => Activator.CreateInstance(x))
              .Cast<T>();

            return all;
        }
    }
}
