﻿namespace FileData.Enum
{
    public enum FileDetail
    {
        Size,
        Version
    }
}
