﻿using FileData.Enum;

namespace FileData.Model
{
    public class FileInfoArguments
    {
        public FileInfoArguments()
        {

        }

        public FileDetail Detail { get; set; }
        public string Path { get; set; }
    }


}
