﻿using FileData.Abstractions;
using FileData.Model;
using FileData.Utils;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public class FileInfoPrinter
    {
        private readonly FileDetails _fileDetails;

        private readonly List<IGetPrinterOutput> _printers;
        public FileInfoPrinter(FileDetails fileDetails)
        {
            _fileDetails = fileDetails;
            _printers = GetPrinters().ToList();
        }


        public void Print(FileInfoArguments arguments)
        {
            var outputs = new List<string>();

            foreach (var item in _printers)
            {
                item.FileDetails = _fileDetails;
                item.GetOutput(arguments);
            }
             
        }

        public virtual IEnumerable<IGetPrinterOutput> GetPrinters()
        {
            return StaticUtils.GetInstancesOfType<IGetPrinterOutput>();
        }
    }
}