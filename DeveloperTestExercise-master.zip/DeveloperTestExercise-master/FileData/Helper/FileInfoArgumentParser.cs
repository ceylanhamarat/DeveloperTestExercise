﻿using FileData.Abstractions;
using FileData.Model;
using FileData.Utils;
using System.Collections.Generic;
using System.Linq;

namespace FileData.Helper
{
    public class FileInfoArgumentParser : IParseArguments
    {

        private  List<IParseArgument> _parsers;

        public FileInfoArgumentParser()
        {
            _parsers = GetParsers().ToList();
        }
        public  IEnumerable<IParseArgument> GetParsers()
        {
            return StaticUtils.GetInstancesOfType<IParseArgument>();
        }
       

        public FileInfoArguments Parse(string[] input)
        {
            var arguments = new FileInfoArguments();

            foreach (var item in _parsers)
            {
                item.ParseArgument(arguments, input);
                
            }
            return arguments;
        }
    }
}
