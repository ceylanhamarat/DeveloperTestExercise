﻿using FileData.Model;
using ThirdPartyTools;

namespace FileData.Abstractions
{
    public interface IGetPrinterOutput
    {
        FileDetails FileDetails { get; set; }
        void GetOutput(FileInfoArguments arguments);
    }
}
