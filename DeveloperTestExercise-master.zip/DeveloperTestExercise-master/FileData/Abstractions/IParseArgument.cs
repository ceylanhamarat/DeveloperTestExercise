﻿using FileData.Model;

namespace FileData.Abstractions
{
    public interface IParseArgument
    {
        void ParseArgument(FileInfoArguments arguments, string[] input);
    }
}
