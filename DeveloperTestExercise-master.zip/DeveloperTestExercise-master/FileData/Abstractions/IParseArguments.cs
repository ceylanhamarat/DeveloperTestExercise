﻿using FileData.Model;

namespace FileData.Abstractions
{
    public interface IParseArguments
    {
        FileInfoArguments Parse(string[] input);
    }
}
